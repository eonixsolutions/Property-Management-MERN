<?php
require_once '../config/config.php';
requireLogin();

$conn = getDBConnection();
$user_id = getCurrentUserId();

// Get date range
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-01-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-12-31');

// Get summary statistics
$total_income = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM transactions 
    WHERE user_id = $user_id AND type = 'Income' 
    AND transaction_date BETWEEN '$start_date' AND '$end_date'")->fetch_assoc()['total'];

$total_expenses = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM transactions 
    WHERE user_id = $user_id AND type = 'Expense' 
    AND transaction_date BETWEEN '$start_date' AND '$end_date'")->fetch_assoc()['total'];

// Get owner rent payments (check if table exists)
$check_owner_table = $conn->query("SHOW TABLES LIKE 'owner_payments'");
$has_owner_table = $check_owner_table->num_rows > 0;

$total_owner_rent = 0;
if ($has_owner_table) {
    $total_owner_rent = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM owner_payments 
        WHERE user_id = $user_id AND status = 'Paid'
        AND paid_date BETWEEN '$start_date' AND '$end_date'")->fetch_assoc()['total'];
}

// Net profit = Income - Expenses - Owner Rent
$net_profit = $total_income - $total_expenses - $total_owner_rent;

// Get income by category
$income_by_category = $conn->query("SELECT category, SUM(amount) as total 
    FROM transactions 
    WHERE user_id = $user_id AND type = 'Income' 
    AND transaction_date BETWEEN '$start_date' AND '$end_date'
    GROUP BY category 
    ORDER BY total DESC");

// Get expenses by category
$expenses_by_category = $conn->query("SELECT category, SUM(amount) as total 
    FROM transactions 
    WHERE user_id = $user_id AND type = 'Expense' 
    AND transaction_date BETWEEN '$start_date' AND '$end_date'
    GROUP BY category 
    ORDER BY total DESC");

// Get monthly summary (with owner rent)
$monthly_summary_query = "SELECT 
    DATE_FORMAT(t.transaction_date, '%Y-%m') as month,
    SUM(CASE WHEN t.type = 'Income' THEN t.amount ELSE 0 END) as income,
    SUM(CASE WHEN t.type = 'Expense' THEN t.amount ELSE 0 END) as expenses";
    
if ($has_owner_table) {
    $monthly_summary_query .= ",
    COALESCE(SUM(op.amount), 0) as owner_rent";
}

$monthly_summary_query .= "
    FROM transactions t";
    
if ($has_owner_table) {
    $monthly_summary_query .= "
    LEFT JOIN (
        SELECT DATE_FORMAT(payment_month, '%Y-%m') as month, SUM(amount) as amount
        FROM owner_payments
        WHERE user_id = $user_id AND status = 'Paid'
        AND DATE_FORMAT(payment_month, '%Y-%m') BETWEEN DATE_FORMAT('$start_date', '%Y-%m') AND DATE_FORMAT('$end_date', '%Y-%m')
        GROUP BY DATE_FORMAT(payment_month, '%Y-%m')
    ) op ON DATE_FORMAT(t.transaction_date, '%Y-%m') = op.month";
}

$monthly_summary_query .= "
    WHERE t.user_id = $user_id 
    AND t.transaction_date BETWEEN '$start_date' AND '$end_date'
    GROUP BY DATE_FORMAT(t.transaction_date, '%Y-%m')";
    
if ($has_owner_table) {
    $monthly_summary_query .= ", op.month";
}

$monthly_summary_query .= "
    ORDER BY month DESC";

$monthly_summary = $conn->query($monthly_summary_query);

// Check if owner columns exist in properties table
$check_owner_name = $conn->query("SHOW COLUMNS FROM properties LIKE 'owner_name'");
$has_owner_columns = $check_owner_name->num_rows > 0;

// Check if unit fields exist
$check_unit = $conn->query("SHOW COLUMNS FROM properties LIKE 'parent_property_id'");
$has_unit_fields = $check_unit->num_rows > 0;

// Property performance (with owner rent and units)
$property_performance_query = "SELECT p.property_name";

if ($has_owner_columns) {
    $property_performance_query .= ", p.owner_name, p.monthly_rent_to_owner";
}

if ($has_unit_fields) {
    $property_performance_query .= ", p.is_unit, p.parent_property_id, parent.property_name as parent_property_name";
}

$property_performance_query .= ",
    SUM(CASE WHEN t.type = 'Income' THEN t.amount ELSE 0 END) as income,
    SUM(CASE WHEN t.type = 'Expense' THEN t.amount ELSE 0 END) as expenses";
    
if ($has_owner_table) {
    $property_performance_query .= ",
    COALESCE(SUM(op.amount), 0) as owner_rent_paid";
}

$property_performance_query .= ",
    SUM(CASE WHEN t.type = 'Income' THEN t.amount ELSE 0 END) 
    - SUM(CASE WHEN t.type = 'Expense' THEN t.amount ELSE 0 END)";
    
if ($has_owner_table) {
    $property_performance_query .= " - COALESCE(SUM(op.amount), 0)";
}

$property_performance_query .= " as net
    FROM properties p";
    
if ($has_unit_fields) {
    $property_performance_query .= " LEFT JOIN properties parent ON p.parent_property_id = parent.id";
}

$property_performance_query .= "
    LEFT JOIN transactions t ON p.id = t.property_id AND t.transaction_date BETWEEN '$start_date' AND '$end_date'";
    
if ($has_owner_table) {
    $property_performance_query .= "
    LEFT JOIN owner_payments op ON p.id = op.property_id AND op.status = 'Paid' 
        AND op.paid_date BETWEEN '$start_date' AND '$end_date'";
}

$property_performance_query .= "
    WHERE p.user_id = $user_id";

// Group master properties only (exclude units from main list, show them grouped)
if ($has_unit_fields) {
    $property_performance_query .= " AND (p.is_unit = 0 OR p.is_unit IS NULL)";
}

if ($has_owner_columns) {
    $property_performance_query .= "
    GROUP BY p.id, p.property_name, p.owner_name, p.monthly_rent_to_owner";
    if ($has_unit_fields) {
        $property_performance_query .= ", p.is_unit, p.parent_property_id, parent.property_name";
    }
} else {
    $property_performance_query .= "
    GROUP BY p.id, p.property_name";
    if ($has_unit_fields) {
        $property_performance_query .= ", p.is_unit, p.parent_property_id, parent.property_name";
    }
}

$property_performance_query .= "
    ORDER BY net DESC";

$property_performance = $conn->query($property_performance_query);
// Connection will be closed after reports are displayed

$page_title = 'Reports';
include '../includes/header.php';
?>

<div class="page-actions">
    <h1>Reports & Analytics</h1>
    <form method="GET" action="" style="display: flex; gap: 12px; align-items: center;">
        <label>From:</label>
        <input type="date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>" required>
        <label>To:</label>
        <input type="date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>" required>
        <button type="submit" class="btn btn-primary">Generate Report</button>
    </form>
</div>

<div class="stats-grid" style="margin-bottom: 30px;">
    <div class="stat-card stat-income">
        <div class="stat-icon">💰</div>
        <div class="stat-content">
            <h3><?php echo formatCurrency($total_income); ?></h3>
            <p>Total Income (Rent Received)</p>
        </div>
    </div>
    <div class="stat-card stat-expense">
        <div class="stat-icon">💸</div>
        <div class="stat-content">
            <h3><?php echo formatCurrency($total_expenses); ?></h3>
            <p>Other Expenses</p>
        </div>
    </div>
    <?php if ($has_owner_table && $total_owner_rent > 0): ?>
    <div class="stat-card" style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);">
        <div class="stat-icon">🏢</div>
        <div class="stat-content">
            <h3><?php echo formatCurrency($total_owner_rent); ?></h3>
            <p>Rent Paid to Owners</p>
        </div>
    </div>
    <?php endif; ?>
    <div class="stat-card <?php echo $net_profit >= 0 ? 'stat-income' : 'stat-expense'; ?>">
        <div class="stat-icon">📊</div>
        <div class="stat-content">
            <h3><?php echo formatCurrency($net_profit); ?></h3>
            <p>Net Profit (After Owner Rent & Expenses)</p>
        </div>
    </div>
</div>

<div class="dashboard-grid">
    <div class="content-card">
        <div class="card-header">
            <h2>Income by Category</h2>
        </div>
        <div class="card-body">
            <?php if ($income_by_category->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Category</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $income_by_category->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['category']); ?></td>
                                    <td class="text-success"><?php echo formatCurrency($row['total']); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted">No income data available</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="content-card">
        <div class="card-header">
            <h2>Expenses by Category</h2>
        </div>
        <div class="card-body">
            <?php if ($expenses_by_category->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Category</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $expenses_by_category->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['category']); ?></td>
                                    <td class="text-danger"><?php echo formatCurrency($row['total']); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted">No expense data available</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="content-card mt-20">
    <div class="card-header">
        <h2>Property Performance</h2>
    </div>
    <div class="card-body">
        <?php if ($property_performance->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Property</th>
                            <?php if ($has_owner_columns): ?>
                            <th>Owner</th>
                            <?php endif; ?>
                            <th>Income</th>
                            <th>Expenses</th>
                            <?php if ($has_owner_table): ?>
                            <th>Owner Rent Paid</th>
                            <?php endif; ?>
                            <th>Net Profit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        // Store property performance data in array for processing
                        $property_data = [];
                        while ($temp_row = $property_performance->fetch_assoc()) {
                            $property_data[] = $temp_row;
                        }
                        
                        // Process each property
                        foreach ($property_data as $row): 
                            // Get units for this master property if it has units
                            $units_rent = 0;
                            $units_data = [];
                            $units_rent_income = 0;
                            
                            if ($has_unit_fields && empty($row['is_unit'])) {
                                // Get property ID from property name (we'll match by name and user)
                                $master_name = $conn->real_escape_string($row['property_name']);
                                $prop_result = $conn->query("SELECT id FROM properties WHERE property_name = '$master_name' AND user_id = $user_id AND (is_unit = 0 OR is_unit IS NULL OR parent_property_id IS NULL) LIMIT 1");
                                if ($prop_result && $prop_result->num_rows > 0) {
                                    $prop_row = $prop_result->fetch_assoc();
                                    $prop_id = $prop_row['id'];
                                    
                                    // Get units and their active rent
                                    $units_query = "SELECT p.id, p.property_name, p.unit_name,
                                        COALESCE(SUM(tn.monthly_rent), 0) as units_rent
                                        FROM properties p
                                        LEFT JOIN tenants tn ON p.id = tn.property_id AND tn.status = 'Active'
                                        WHERE p.parent_property_id = $prop_id
                                        GROUP BY p.id, p.property_name, p.unit_name";
                                    $units_result = $conn->query($units_query);
                                    if ($units_result) {
                                        while ($unit = $units_result->fetch_assoc()) {
                                            $units_data[] = $unit;
                                            $units_rent += $unit['units_rent'];
                                        }
                                    }
                                    
                                    // Get rent income from units' tenants (paid rent in period)
                                    $units_rent_result = $conn->query("SELECT COALESCE(SUM(rp.amount), 0) as total 
                                        FROM rent_payments rp
                                        INNER JOIN properties p ON rp.property_id = p.id
                                        WHERE p.parent_property_id = $prop_id 
                                        AND rp.status = 'Paid'
                                        AND rp.paid_date BETWEEN '$start_date' AND '$end_date'");
                                    if ($units_rent_result && $units_rent_result->num_rows > 0) {
                                        $units_rent_income = $units_rent_result->fetch_assoc()['total'];
                                    }
                                    
                                    // If master has owner rent, calculate profit including units
                                    if ($has_owner_columns && !empty($row['owner_name']) && !empty($row['monthly_rent_to_owner']) && $row['monthly_rent_to_owner'] > 0) {
                                        $owner_rent_for_period = $has_owner_table ? ($row['owner_rent_paid'] ?? 0) : 0;
                                        // Net = (Income from all units + other income) - Expenses - Owner Rent
                                        $total_income_with_units = $row['income'] + $units_rent_income;
                                        $row['net'] = $total_income_with_units - $row['expenses'] - $owner_rent_for_period;
                                        $row['income'] = $total_income_with_units;
                                    } else {
                                        // Just add units rent to income
                                        $row['income'] = $row['income'] + $units_rent_income;
                                        $row['net'] = $row['income'] - $row['expenses'];
                                    }
                                }
                            }
                        ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($row['property_name']); ?></strong>
                                    <?php if ($has_unit_fields && !empty($row['is_unit'])): ?>
                                        <br><small style="color: #64748b;">Unit of: <?php echo htmlspecialchars($row['parent_property_name'] ?? 'Unknown'); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($has_owner_columns): ?>
                                        <?php if (!empty($row['owner_name'])): ?>
                                            <span style="color: #6366f1;"><?php echo htmlspecialchars($row['owner_name']); ?></span>
                                            <?php if (!empty($row['monthly_rent_to_owner']) && $row['monthly_rent_to_owner'] > 0): ?>
                                                <br><small style="color: #64748b;"><?php echo formatCurrency($row['monthly_rent_to_owner']); ?>/mo</small>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span style="color: #94a3b8;">Self-owned</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span style="color: #94a3b8;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-success">
                                    <?php echo formatCurrency($row['income']); ?>
                                    <?php if ($has_unit_fields && $units_rent > 0): ?>
                                        <br><small style="color: #10b981;">+ <?php echo count($units_data); ?> unit(s): <?php echo formatCurrency($units_rent); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-danger"><?php echo formatCurrency($row['expenses']); ?></td>
                                <?php if ($has_owner_table): ?>
                                <td class="text-warning"><?php echo formatCurrency($row['owner_rent_paid'] ?? 0); ?></td>
                                <?php endif; ?>
                                <td class="<?php echo $row['net'] >= 0 ? 'text-success' : 'text-danger'; ?>">
                                    <strong><?php echo formatCurrency($row['net']); ?></strong>
                                </td>
                            </tr>
                            <?php if ($has_unit_fields && count($units_data) > 0): ?>
                                <?php foreach ($units_data as $unit): ?>
                                <tr style="background: #f9fafb;">
                                    <td style="padding-left: 40px;">
                                        └─ <small><?php echo htmlspecialchars($unit['unit_name'] ?? $unit['property_name']); ?></small>
                                    </td>
                                    <td><small style="color: #94a3b8;">Unit</small></td>
                                    <td class="text-success"><small><?php echo formatCurrency($unit['units_rent']); ?></small></td>
                                    <td><small>-</small></td>
                                    <?php if ($has_owner_table): ?>
                                    <td><small>-</small></td>
                                    <?php endif; ?>
                                    <td><small class="text-success"><?php echo formatCurrency($unit['units_rent']); ?></small></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted">No property performance data available</p>
        <?php endif; ?>
    </div>
</div>

<div class="content-card mt-20">
    <div class="card-header">
        <h2>Monthly Summary</h2>
    </div>
    <div class="card-body">
        <?php if ($monthly_summary->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Month</th>
                            <th>Income</th>
                            <th>Expenses</th>
                            <?php if ($has_owner_table): ?>
                            <th>Owner Rent</th>
                            <?php endif; ?>
                            <th>Net Profit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $monthly_summary->fetch_assoc()): 
                            $owner_rent = $has_owner_table ? ($row['owner_rent'] ?? 0) : 0;
                            $net = $row['income'] - $row['expenses'] - $owner_rent;
                        ?>
                            <tr>
                                <td><strong><?php echo date('F Y', strtotime($row['month'] . '-01')); ?></strong></td>
                                <td class="text-success"><?php echo formatCurrency($row['income']); ?></td>
                                <td class="text-danger"><?php echo formatCurrency($row['expenses']); ?></td>
                                <?php if ($has_owner_table): ?>
                                <td class="text-warning"><?php echo formatCurrency($owner_rent); ?></td>
                                <?php endif; ?>
                                <td class="<?php echo $net >= 0 ? 'text-success' : 'text-danger'; ?>">
                                    <strong><?php echo formatCurrency($net); ?></strong>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted">No monthly data available</p>
        <?php endif; ?>
    </div>
</div>

<?php 
closeDBConnection($conn);
include '../includes/footer.php'; 
?>
