<?php
/**
 * Recurring Invoices System
 * Automatically generates rent invoices for tenants
 */

require_once __DIR__ . '/../config/config.php';

/**
 * Generate recurring rent invoices for a tenant
 */
function generateRecurringInvoices($tenant_id, $conn = null) {
    if ($conn === null) {
        $conn = getDBConnection();
    }
    
    // Get tenant details
    $tenant = $conn->query("SELECT * FROM tenants WHERE id = $tenant_id")->fetch_assoc();
    
    if (!$tenant || $tenant['status'] != 'Active') {
        return false;
    }
    
    // Check if invoices already generated for this tenant
    $existing_invoices = $conn->query("SELECT COUNT(*) as count FROM rent_payments WHERE tenant_id = $tenant_id")->fetch_assoc()['count'];
    
    if ($existing_invoices > 0) {
        // Invoices already generated, skip
        return false;
    }
    
    $lease_start = $tenant['lease_start'] ? $tenant['lease_start'] : $tenant['move_in_date'];
    $lease_end = $tenant['lease_end'];
    $monthly_rent = $tenant['monthly_rent'];
    $property_id = $tenant['property_id'];
    
    if (!$lease_start || !$lease_end || !$monthly_rent) {
        return false;
    }
    
    // Generate invoices from lease_start to lease_end
    $start_date = new DateTime($lease_start);
    $end_date = new DateTime($lease_end);
    $current_date = clone $start_date;
    
    $invoices_created = 0;
    
    while ($current_date <= $end_date) {
        $due_date = $current_date->format('Y-m-d');
        
        // Check if invoice already exists for this date
        $exists = $conn->query("SELECT id FROM rent_payments 
            WHERE tenant_id = $tenant_id 
            AND DATE_FORMAT(due_date, '%Y-%m') = '" . $current_date->format('Y-m') . "'")->num_rows;
        
        if (!$exists) {
            $stmt = $conn->prepare("INSERT INTO rent_payments (tenant_id, property_id, amount, due_date, status) VALUES (?, ?, ?, ?, 'Pending')");
            $stmt->bind_param("iids", $tenant_id, $property_id, $monthly_rent, $due_date);
            
            if ($stmt->execute()) {
                $invoices_created++;
            }
            $stmt->close();
        }
        
        // Move to next month
        $current_date->modify('+1 month');
    }
    
    return $invoices_created;
}

/**
 * Generate invoices for all active tenants (for cron job)
 */
function generateAllRecurringInvoices() {
    $conn = getDBConnection();
    
    // Get all active tenants
    $tenants = $conn->query("SELECT id FROM tenants WHERE status = 'Active'");
    
    $total_invoices = 0;
    
    while ($tenant = $tenants->fetch_assoc()) {
        // Generate invoices for current and future months
        generateMonthlyInvoices($tenant['id'], $conn);
        $total_invoices++;
    }
    
    closeDBConnection($conn);
    return $total_invoices;
}

/**
 * Generate invoices for current and upcoming months for a tenant
 */
function generateMonthlyInvoices($tenant_id, $conn = null) {
    if ($conn === null) {
        $conn = getDBConnection();
    }
    
    // Get tenant details
    $tenant = $conn->query("SELECT * FROM tenants WHERE id = $tenant_id")->fetch_assoc();
    
    if (!$tenant || $tenant['status'] != 'Active') {
        return false;
    }
    
    $lease_start = $tenant['lease_start'] ? $tenant['lease_start'] : $tenant['move_in_date'];
    $lease_end = $tenant['lease_end'];
    $monthly_rent = $tenant['monthly_rent'];
    $property_id = $tenant['property_id'];
    
    if (!$lease_start || !$lease_end || !$monthly_rent) {
        return false;
    }
    
    $lease_end_date = new DateTime($lease_end);
    $current_date = new DateTime();
    
    // Generate invoices for next 12 months from today (or until lease end)
    $target_date = clone $current_date;
    $target_date->modify('+12 months');
    
    if ($lease_end_date < $target_date) {
        $target_date = $lease_end_date;
    }
    
    $invoices_created = 0;
    $check_date = clone $current_date;
    
    // Check and create invoices for next 12 months
    while ($check_date <= $target_date && $check_date <= $lease_end_date) {
        $due_date = $check_date->format('Y-m-01'); // First day of the month
        
        // Check if invoice already exists for this month
        $exists = $conn->query("SELECT id FROM rent_payments 
            WHERE tenant_id = $tenant_id 
            AND DATE_FORMAT(due_date, '%Y-%m') = '" . $check_date->format('Y-m') . "'")->num_rows;
        
        if (!$exists && $check_date >= new DateTime($lease_start)) {
            $stmt = $conn->prepare("INSERT INTO rent_payments (tenant_id, property_id, amount, due_date, status) VALUES (?, ?, ?, ?, 'Pending')");
            $stmt->bind_param("iids", $tenant_id, $property_id, $monthly_rent, $due_date);
            
            if ($stmt->execute()) {
                $invoices_created++;
            }
            $stmt->close();
        }
        
        // Move to next month
        $check_date->modify('+1 month');
    }
    
    return $invoices_created;
}
?>
