<?php
require_once '../config/config.php';
requireLogin();

$conn = getDBConnection();
$user_id = getCurrentUserId();

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: index.php');
    exit();
}

$property_id = intval($_GET['id']);

// Get property details
$stmt = $conn->prepare("SELECT * FROM properties WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $property_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    header('Location: index.php');
    exit();
}

$property = $result->fetch_assoc();
$stmt->close();

// Get tenants for this property
$tenants = $conn->query("SELECT * FROM tenants WHERE property_id = $property_id ORDER BY move_in_date DESC");

// Get transactions for this property
$transactions = $conn->query("SELECT t.*, tn.first_name, tn.last_name 
    FROM transactions t
    LEFT JOIN tenants tn ON t.tenant_id = tn.id
    WHERE t.property_id = $property_id
    ORDER BY t.transaction_date DESC
    LIMIT 10");

// Check if unit fields exist
$check_unit_fields = $conn->query("SHOW COLUMNS FROM properties LIKE 'parent_property_id'");
$has_unit_fields = $check_unit_fields->num_rows > 0;

// Get units if this is a master property
$units = null;
$parent_property = null;

if ($has_unit_fields) {
    $units = $conn->query("SELECT id, property_name, unit_name, is_unit FROM properties WHERE parent_property_id = $property_id AND user_id = $user_id ORDER BY unit_name");
    
    // Check if this property is a unit
    if (isset($property['is_unit']) && $property['is_unit'] && !empty($property['parent_property_id'])) {
        $parent_property = $conn->query("SELECT * FROM properties WHERE id = {$property['parent_property_id']} AND user_id = $user_id")->fetch_assoc();
    }
}

closeDBConnection($conn);

$page_title = 'View Property';
include '../includes/header.php';
?>

<div class="page-actions">
    <h1>
        <?php echo htmlspecialchars($property['property_name']); ?>
        <?php if ($has_unit_fields && $parent_property): ?>
            <span class="badge badge-info">Unit</span>
        <?php endif; ?>
    </h1>
    <div>
        <?php if ($has_unit_fields && !$parent_property): ?>
            <a href="add.php?parent_id=<?php echo $property['id']; ?>" class="btn" style="margin-right: 12px;">+ Add Unit</a>
        <?php endif; ?>
        <a href="edit.php?id=<?php echo $property['id']; ?>" class="btn btn-primary">Edit Property</a>
        <a href="index.php" class="btn-link">← Back to Properties</a>
    </div>
</div>

<?php if ($has_unit_fields && $parent_property): ?>
    <div class="alert alert-info">
        <strong>Unit Information:</strong> This property is a unit of 
        <a href="view.php?id=<?php echo $parent_property['id']; ?>"><?php echo htmlspecialchars($parent_property['property_name']); ?></a>
        <?php if (!empty($parent_property['owner_name'])): ?>
            (Owner: <?php echo htmlspecialchars($parent_property['owner_name']); ?> - 
            Rent: <?php echo formatCurrency($parent_property['monthly_rent_to_owner']); ?>/month)
        <?php endif; ?>
    </div>
<?php endif; ?>

<div class="dashboard-grid">
    <div class="content-card">
        <div class="card-header">
            <h2>Property Details</h2>
        </div>
        <div class="card-body">
            <table class="data-table">
                <tr>
                    <td><strong>Property Name</strong></td>
                    <td><?php echo htmlspecialchars($property['property_name']); ?></td>
                </tr>
                <tr>
                    <td><strong>Address</strong></td>
                    <td><?php echo htmlspecialchars($property['address']); ?></td>
                </tr>
                <tr>
                    <td><strong>City</strong></td>
                    <td><?php echo htmlspecialchars($property['city']); ?></td>
                </tr>
                <tr>
                    <td><strong>State</strong></td>
                    <td><?php echo htmlspecialchars($property['state'] ?? '-'); ?></td>
                </tr>
                <tr>
                    <td><strong>Zip Code</strong></td>
                    <td><?php echo htmlspecialchars($property['zip_code'] ?? '-'); ?></td>
                </tr>
                <tr>
                    <td><strong>Property Type</strong></td>
                    <td><?php echo htmlspecialchars($property['property_type']); ?></td>
                </tr>
                <tr>
                    <td><strong>Status</strong></td>
                    <td>
                        <span class="badge badge-<?php 
                            echo $property['status'] == 'Occupied' ? 'success' : 
                                ($property['status'] == 'Under Maintenance' ? 'warning' : 'info'); 
                        ?>">
                            <?php echo htmlspecialchars($property['status']); ?>
                        </span>
                    </td>
                </tr>
                <tr>
                    <td><strong>Bedrooms</strong></td>
                    <td><?php echo $property['bedrooms'] ?? '-'; ?></td>
                </tr>
                <tr>
                    <td><strong>Bathrooms</strong></td>
                    <td><?php echo $property['bathrooms'] ?? '-'; ?></td>
                </tr>
                <tr>
                    <td><strong>Square Feet</strong></td>
                    <td><?php echo $property['square_feet'] ? number_format($property['square_feet']) : '-'; ?></td>
                </tr>
                <tr>
                    <td><strong>Current Value</strong></td>
                    <td><?php echo formatCurrency($property['current_value'] ?? 0); ?></td>
                </tr>
                <?php if ($property['notes']): ?>
                <tr>
                    <td><strong>Notes</strong></td>
                    <td><?php echo nl2br(htmlspecialchars($property['notes'])); ?></td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>

    <?php if ($has_unit_fields && $units && $units->num_rows > 0): ?>
    <div class="content-card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h2>🏗️ Property Units (<?php echo $units->num_rows; ?>)</h2>
            <a href="add.php?parent_id=<?php echo $property['id']; ?>" class="btn-link">+ Add Unit</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Unit Name</th>
                            <th>Tenants</th>
                            <th>Total Rent</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total_units_rent = 0;
                        while ($unit = $units->fetch_assoc()): 
                            $total_units_rent += $unit['total_rent'];
                        ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($unit['unit_name'] ?? $unit['property_name']); ?></strong></td>
                                <td><?php echo $unit['active_tenants']; ?></td>
                                <td><?php echo formatCurrency($unit['total_rent'] ?? 0); ?></td>
                                <td>
                                    <span class="badge badge-<?php 
                                        echo $unit['status'] == 'Occupied' ? 'success' : 
                                            ($unit['status'] == 'Under Maintenance' ? 'warning' : 'info'); 
                                    ?>">
                                        <?php echo htmlspecialchars($unit['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="view.php?id=<?php echo $unit['id']; ?>" class="btn-link">View</a>
                                    <a href="edit.php?id=<?php echo $unit['id']; ?>" class="btn-link">Edit</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                    <tfoot>
                        <tr style="background: #f0f9ff; font-weight: 600;">
                            <td><strong>Total Units Rent</strong></td>
                            <td></td>
                            <td><strong><?php echo formatCurrency($total_units_rent); ?></strong></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <?php if (!empty($property['owner_name']) && !empty($property['monthly_rent_to_owner'])): ?>
                        <tr style="background: #fef3c7; font-weight: 600;">
                            <td><strong>Owner Rent (Monthly)</strong></td>
                            <td></td>
                            <td><strong>-<?php echo formatCurrency($property['monthly_rent_to_owner']); ?></strong></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr style="background: #d1fae5; font-weight: 600;">
                            <td><strong>Net Profit (Monthly)</strong></td>
                            <td></td>
                            <td><strong><?php echo formatCurrency($total_units_rent - $property['monthly_rent_to_owner']); ?></strong></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <?php endif; ?>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="content-card">
        <div class="card-header">
            <h2>Tenants</h2>
            <a href="../tenants/add.php?property_id=<?php echo $property['id']; ?>" class="btn-link">+ Add Tenant</a>
        </div>
        <div class="card-body">
            <?php if ($tenants->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Monthly Rent</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($tenant = $tenants->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($tenant['first_name'] . ' ' . $tenant['last_name']); ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo $tenant['status'] == 'Active' ? 'success' : 'info'; ?>">
                                            <?php echo htmlspecialchars($tenant['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo formatCurrency($tenant['monthly_rent']); ?></td>
                                    <td>
                                        <a href="../tenants/view.php?id=<?php echo $tenant['id']; ?>" class="btn-link">View</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted">No tenants for this property.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="content-card mt-20">
    <div class="card-header">
        <h2>Recent Transactions</h2>
        <a href="../transactions/add.php?property_id=<?php echo $property['id']; ?>" class="btn-link">+ Add Transaction</a>
    </div>
    <div class="card-body">
        <?php if ($transactions->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Type</th>
                            <th>Category</th>
                            <th>Amount</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($transaction = $transactions->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo formatDate($transaction['transaction_date']); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $transaction['type'] == 'Income' ? 'success' : 'danger'; ?>">
                                        <?php echo $transaction['type']; ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($transaction['category']); ?></td>
                                <td class="<?php echo $transaction['type'] == 'Income' ? 'text-success' : 'text-danger'; ?>">
                                    <?php echo $transaction['type'] == 'Income' ? '+' : '-'; ?><?php echo formatCurrency($transaction['amount']); ?>
                                </td>
                                <td><?php echo htmlspecialchars($transaction['description'] ?? '-'); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted">No transactions for this property.</p>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
