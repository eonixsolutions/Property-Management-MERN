<?php
require_once '../config/config.php';
requireLogin();

$conn = getDBConnection();
$user_id = getCurrentUserId();

// Handle delete
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $property_id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM properties WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $property_id, $user_id);
    $stmt->execute();
    $stmt->close();
    header('Location: index.php?deleted=1');
    exit();
}

// Get search and filter parameters
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? $conn->real_escape_string($_GET['status']) : '';
$property_type_filter = isset($_GET['property_type']) ? $conn->real_escape_string($_GET['property_type']) : '';

$page_title = 'Properties';
include '../includes/header.php';

// Check if unit fields exist (after header to keep connection open)
$check_unit = $conn->query("SHOW COLUMNS FROM properties LIKE 'parent_property_id'");
$has_unit_fields = $check_unit->num_rows > 0;

// Build WHERE clause with filters
$where_clause = "p.user_id = $user_id";

if (!empty($search)) {
    $where_clause .= " AND (p.property_name LIKE '%$search%' OR p.address LIKE '%$search%' OR p.city LIKE '%$search%' OR p.property_type LIKE '%$search%')";
}

if (!empty($status_filter)) {
    $where_clause .= " AND p.status = '$status_filter'";
}

if (!empty($property_type_filter)) {
    $where_clause .= " AND p.property_type = '$property_type_filter'";
}

// Get all properties (master properties and units)
$properties_query = "SELECT p.*, 
    (SELECT COUNT(*) FROM tenants WHERE property_id = p.id AND status = 'Active') as active_tenants,
    (SELECT SUM(monthly_rent) FROM tenants WHERE property_id = p.id AND status = 'Active') as monthly_rent";
    
if ($has_unit_fields) {
    $properties_query .= ", parent.property_name as parent_property_name, p.unit_name, p.is_unit";
}

$properties_query .= " FROM properties p";

if ($has_unit_fields) {
    $properties_query .= " LEFT JOIN properties parent ON p.parent_property_id = parent.id";
}

$properties_query .= " WHERE $where_clause";

if ($has_unit_fields) {
    $properties_query .= " ORDER BY p.parent_property_id ASC, p.is_unit ASC, p.created_at DESC";
} else {
    $properties_query .= " ORDER BY p.created_at DESC";
}

$properties = $conn->query($properties_query);

// Get distinct property types and statuses for filter dropdowns
$property_types = $conn->query("SELECT DISTINCT property_type FROM properties WHERE user_id = $user_id AND property_type IS NOT NULL AND property_type != '' ORDER BY property_type");
$statuses = ['Occupied', 'Vacant', 'Under Maintenance'];
?>

<div class="page-actions">
    <h1>Properties</h1>
    <a href="add.php" class="btn btn-primary">+ Add Property</a>
</div>

<?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-success">Property deleted successfully!</div>
<?php endif; ?>

<?php if (isset($_GET['added'])): ?>
    <div class="alert alert-success">Property added successfully!</div>
<?php endif; ?>

<?php if (isset($_GET['updated'])): ?>
    <div class="alert alert-success">Property updated successfully!</div>
<?php endif; ?>

<!-- Search and Filter -->
<div class="content-card" style="margin-bottom: 20px;">
    <div class="card-body">
        <form method="GET" action="" style="display: flex; gap: 12px; flex-wrap: wrap; align-items: end;">
            <div style="flex: 1; min-width: 200px;">
                <label for="search" style="font-size: 12px; margin-bottom: 4px; display: block;">Search</label>
                <input type="text" id="search" name="search" placeholder="Search by name, address, city..." value="<?php echo htmlspecialchars($search); ?>" style="width: 100%;">
            </div>
            
            <div style="min-width: 150px;">
                <label for="status_filter" style="font-size: 12px; margin-bottom: 4px; display: block;">Status</label>
                <select id="status_filter" name="status" style="width: 100%;">
                    <option value="">All Statuses</option>
                    <?php foreach ($statuses as $status): ?>
                        <option value="<?php echo htmlspecialchars($status); ?>" <?php echo $status_filter == $status ? 'selected' : ''; ?>><?php echo htmlspecialchars($status); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div style="min-width: 150px;">
                <label for="property_type_filter" style="font-size: 12px; margin-bottom: 4px; display: block;">Property Type</label>
                <select id="property_type_filter" name="property_type" style="width: 100%;">
                    <option value="">All Types</option>
                    <?php while ($pt = $property_types->fetch_assoc()): ?>
                        <option value="<?php echo htmlspecialchars($pt['property_type']); ?>" <?php echo $property_type_filter == $pt['property_type'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($pt['property_type']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div>
                <button type="submit" class="btn btn-primary">🔍 Search</button>
                <?php if (!empty($search) || !empty($status_filter) || !empty($property_type_filter)): ?>
                    <a href="index.php" class="btn" style="margin-left: 8px;">Clear</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="content-card">
    <div class="card-body">
        <?php if ($properties->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Property Name</th>
                            <?php if ($has_unit_fields): ?>
                            <th>Type</th>
                            <?php endif; ?>
                            <th>Address</th>
                            <th>Property Type</th>
                            <th>Status</th>
                            <th>Tenants</th>
                            <th>Monthly Rent</th>
                            <th>Current Value</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
<?php 
$current_parent_id = null;
while ($property = $properties->fetch_assoc()): 
    $is_unit = $has_unit_fields && !empty($property['is_unit']) && $property['is_unit'];
    $parent_id = $has_unit_fields ? ($property['parent_property_id'] ?? null) : null;
    
    // Show header for new parent property group
    if ($has_unit_fields && $parent_id != $current_parent_id && !$is_unit && $parent_id === null) {
        $current_parent_id = $property['id'];
        // Check if this property has units
        $unit_count = $conn->query("SELECT COUNT(*) as count FROM properties WHERE parent_property_id = {$property['id']}")->fetch_assoc()['count'];
        if ($unit_count > 0) {
            $colspan = $has_unit_fields ? 9 : 8;
            echo '<tr style="background: #f0f9ff; border-top: 2px solid #3b82f6;"><td colspan="' . $colspan . '"><strong>📦 Master Property: ' . htmlspecialchars($property['property_name']) . '</strong> (' . $unit_count . ' unit(s))</td></tr>';
        }
    }
    
    // Reset current_parent_id if we hit a new master property
    if ($has_unit_fields && !$is_unit && $parent_id === null) {
        $current_parent_id = $property['id'];
    }
?>
                            <tr style="<?php echo $is_unit ? 'background: #f9fafb; padding-left: 30px;' : ''; ?>">
                                <td>
                                    <?php if ($is_unit): ?>
                                        <span style="margin-right: 10px;">└─</span>
                                        <strong><?php echo htmlspecialchars($property['unit_name'] ?? $property['property_name']); ?></strong>
                                        <br><small style="color: #64748b;">Part of: <?php echo htmlspecialchars($property['parent_property_name'] ?? 'Unknown'); ?></small>
                                    <?php else: ?>
                                        <strong><?php echo htmlspecialchars($property['property_name']); ?></strong>
                                    <?php endif; ?>
                                </td>
                                <?php if ($has_unit_fields): ?>
                                <td>
                                    <?php if ($is_unit): ?>
                                        <span class="badge badge-info">Unit</span>
                                    <?php else: ?>
                                        <span class="badge" style="background: #6366f1;">Master</span>
                                    <?php endif; ?>
                                </td>
                                <?php endif; ?>
                                <td><?php echo htmlspecialchars($property['address'] . ', ' . $property['city']); ?></td>
                                <td><?php echo htmlspecialchars($property['property_type']); ?></td>
                                <td>
                                    <span class="badge badge-<?php 
                                        echo $property['status'] == 'Occupied' ? 'success' : 
                                            ($property['status'] == 'Under Maintenance' ? 'warning' : 'info'); 
                                    ?>">
                                        <?php echo htmlspecialchars($property['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo $property['active_tenants']; ?></td>
                                <td><?php echo formatCurrency($property['monthly_rent'] ?? 0); ?></td>
                                <td><?php echo formatCurrency($property['current_value'] ?? 0); ?></td>
                                <td>
                                    <a href="view.php?id=<?php echo $property['id']; ?>" class="btn-link">View</a>
                                    <a href="edit.php?id=<?php echo $property['id']; ?>" class="btn-link">Edit</a>
                                    <?php if (!$is_unit): ?>
                                    <a href="add.php?parent_id=<?php echo $property['id']; ?>" class="btn-link" title="Add Unit">+ Unit</a>
                                    <?php endif; ?>
                                    <a href="?delete=<?php echo $property['id']; ?>" 
                                       onclick="return confirmDelete('Are you sure you want to delete this property?')" 
                                       class="btn-link text-danger">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center" style="padding: 60px 20px;">
                <p class="text-muted" style="font-size: 18px; margin-bottom: 20px;">No properties yet</p>
                <a href="add.php" class="btn btn-primary">Add Your First Property</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php 
closeDBConnection($conn);
include '../includes/footer.php'; 
?>
