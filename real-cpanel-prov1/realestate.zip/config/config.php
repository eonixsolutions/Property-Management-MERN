<?php
// Application Configuration
session_start();

// Base URL
define('BASE_URL', 'http://localhost/realestate');

// Session timeout in seconds (10 minutes = 600 seconds)
define('SESSION_TIMEOUT', 600);

// Timezone
date_default_timezone_set('UTC');

// Error Reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database configuration
require_once __DIR__ . '/database.php';

// Initialize last activity time if not set
if (isset($_SESSION['user_id']) && !isset($_SESSION['last_activity'])) {
    $_SESSION['last_activity'] = time();
}

// Check session timeout
if (isset($_SESSION['user_id']) && isset($_SESSION['last_activity'])) {
    $timeSinceLastActivity = time() - $_SESSION['last_activity'];
    
    if ($timeSinceLastActivity > SESSION_TIMEOUT) {
        // Session expired - clear session and redirect to login
        session_unset();
        session_destroy();
        
        // Check if this is an AJAX request
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['timeout' => true, 'redirect' => BASE_URL . '/auth/login.php?timeout=1']);
            exit();
        } else {
            header('Location: ' . BASE_URL . '/auth/login.php?timeout=1');
            exit();
        }
    }
}

// Update last activity time on each request
if (isset($_SESSION['user_id'])) {
    $_SESSION['last_activity'] = time();
}

// Helper function to check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Helper function to redirect if not logged in
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . '/auth/login.php');
        exit();
    }
}

// Helper function to get current user ID
function getCurrentUserId() {
    return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
}

// Helper function to sanitize input
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Currency symbols mapping
function getCurrencySymbol($currency_code) {
    $currencies = [
        'USD' => '$',
        'QAR' => 'ر.ق',  // Qatar Riyal
        'SAR' => 'ر.س',  // Saudi Riyal
        'AED' => 'د.إ',  // UAE Dirham
        'EUR' => '€',
        'GBP' => '£',
        'CAD' => 'C$',
        'AUD' => 'A$',
        'JPY' => '¥',
        'INR' => '₹',
        'PKR' => '₨',
        'EGP' => 'E£',
        'BHD' => '.د.ب',
        'KWD' => 'د.ك',
        'OMR' => 'ر.ع.',
    ];
    return isset($currencies[$currency_code]) ? $currencies[$currency_code] : '$';
}

// Helper function to get user's currency
function getUserCurrency() {
    if (!isLoggedIn()) {
        return 'USD'; // Default
    }
    
    // Get currency from session if set
    if (isset($_SESSION['user_currency'])) {
        return $_SESSION['user_currency'];
    }
    
    // Get from database
    $conn = getDBConnection();
    $user_id = getCurrentUserId();
    $result = $conn->query("SELECT currency FROM settings WHERE user_id = $user_id LIMIT 1");
    
    if ($result && $result->num_rows > 0) {
        $currency = $result->fetch_assoc()['currency'];
        if (empty($currency)) {
            $currency = 'QAR'; // Default to QAR
        }
    } else {
        $currency = 'QAR'; // Default to QAR
    }
    
    $_SESSION['user_currency'] = $currency;
    closeDBConnection($conn);
    
    return $currency;
}

// Helper function to format currency
function formatCurrency($amount, $currency_code = null) {
    if ($currency_code === null) {
        $currency_code = getUserCurrency();
    }
    
    $symbol = getCurrencySymbol($currency_code);
    $formatted = number_format($amount, 2);
    
    // For RTL currencies (Arabic), put symbol after the number
    $rtl_currencies = ['QAR', 'SAR', 'AED', 'BHD', 'KWD', 'OMR'];
    if (in_array($currency_code, $rtl_currencies)) {
        return $formatted . ' ' . $symbol;
    } else {
        return $symbol . $formatted;
    }
}

// Helper function to format date
function formatDate($date) {
    if (empty($date) || $date == '0000-00-00') {
        return '-';
    }
    return date('M d, Y', strtotime($date));
}
?>
