<?php
require_once '../config/config.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit();
}

$error = '';
$timeout_message = '';

// Check if redirected due to session timeout
if (isset($_GET['timeout']) && $_GET['timeout'] == '1') {
    $timeout_message = 'Your session has expired due to inactivity. Please log in again.';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];
    
    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields';
    } else {
        $conn = getDBConnection();
        $stmt = $conn->prepare("SELECT id, email, password, first_name, last_name FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            
            // Check password (allows plain text for demo user, otherwise use password_verify)
            if ($user['email'] === 'sidhykqatar@gmail.com' && $password === 'tz669933') {
                // Demo user - plain text check
                $password_valid = true;
            } else {
                // Regular users - verify hash
                $password_valid = password_verify($password, $user['password']);
            }
            
            if ($password_valid) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
                $_SESSION['last_activity'] = time(); // Initialize last activity time
                
                // Load user currency settings
                $settings_result = $conn->query("SELECT currency FROM settings WHERE user_id = " . $user['id'] . " LIMIT 1");
                if ($settings_result && $settings_result->num_rows > 0) {
                    $user_settings = $settings_result->fetch_assoc();
                    $_SESSION['user_currency'] = !empty($user_settings['currency']) ? $user_settings['currency'] : 'QAR';
                } else {
                    $_SESSION['user_currency'] = 'QAR'; // Default to QAR
                }
                
                header('Location: ' . BASE_URL . '/index.php');
                exit();
            } else {
                $error = 'Invalid email or password';
            }
        } else {
            $error = 'Invalid email or password';
        }
        
        $stmt->close();
        closeDBConnection($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Real Estate Management</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="auth-page">
    <div class="login-container">
        <!-- Left Panel - Promotional -->
        <div class="login-left-panel">
            <div class="login-branding">
                <div class="logo-large">
                    <span class="logo-icon">🏠</span>
                    <span class="logo-text">Real Estate</span>
                </div>
                <h2 class="tagline">Simple <span class="highlight">accounting</span> software for landlords.</h2>
            </div>
            <div class="dashboard-preview">
                <div class="preview-card">
                    <div class="preview-header">
                        <p>Dashboard Overview</p>
                    </div>
                    <div class="preview-stats">
                        <div class="preview-stat">
                            <span class="stat-label">Total Properties</span>
                            <span class="stat-value">12</span>
                        </div>
                        <div class="preview-stat">
                            <span class="stat-label">Monthly Income</span>
                            <span class="stat-value">$15,420</span>
                        </div>
                        <div class="preview-stat">
                            <span class="stat-label">Active Tenants</span>
                            <span class="stat-value">8</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Panel - Login Form -->
        <div class="login-right-panel">
            <div class="login-wrapper">
                <a href="#" class="tenant-link">Are you a tenant? <span>Sign in here</span></a>
                
                <div class="login-header">
                    <h1>Welcome</h1>
                </div>

                <?php if ($timeout_message): ?>
                    <div class="alert alert-warning"><?php echo htmlspecialchars($timeout_message); ?></div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <!-- Social Login Buttons -->
                       <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                      

                <!-- Separator -->
                <div class="login-separator">
                   
                </div>

                <!-- Login Form -->
                <form method="POST" action="" class="login-form">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : 'sidhykqatar@gmail.com'; ?>" placeholder="Enter your email">
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required placeholder="Enter your password">
                        <a href="#" class="forgot-password-link">Forgot Password?</a>
                    </div>
                    
                    <button type="submit" class="btn-login">Log In</button>
                </form>

                <div class="login-footer">
                    <p>Don't have an account? <a href="register.php">Register</a></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
