<?php
require_once '../config/config.php';
requireLogin();

$conn = getDBConnection();
$user_id = getCurrentUserId();

// Check if owner_payments table exists
$check_table = $conn->query("SHOW TABLES LIKE 'owner_payments'");
$has_owner_table = $check_table->num_rows > 0;

if (!$has_owner_table) {
    closeDBConnection($conn);
    die('Owner payments table not found. Please run the migration: <a href="../database/migrate_owner.php">Run Migration</a>');
}

// Handle mark as paid
if (isset($_GET['mark_paid']) && is_numeric($_GET['mark_paid'])) {
    $payment_id = intval($_GET['mark_paid']);
    $paid_date = date('Y-m-d');
    
    $stmt = $conn->prepare("UPDATE owner_payments SET status = 'Paid', paid_date = ? WHERE id = ? AND user_id = ?");
    $stmt->bind_param("sii", $paid_date, $payment_id, $user_id);
    $stmt->execute();
    $stmt->close();
    
    header('Location: index.php?paid=1');
    exit();
}

// Handle delete
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $payment_id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM owner_payments WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $payment_id, $user_id);
    $stmt->execute();
    $stmt->close();
    header('Location: index.php?deleted=1');
    exit();
}

// Get search and filter parameters
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$month = isset($_GET['month']) ? $conn->real_escape_string($_GET['month']) : date('Y-m');
$status_filter = isset($_GET['status']) ? $conn->real_escape_string($_GET['status']) : '';
$property_filter = isset($_GET['property']) ? intval($_GET['property']) : 0;

// Build WHERE clause
$where_clause = "op.user_id = $user_id AND DATE_FORMAT(op.payment_month, '%Y-%m') = '$month'";

if (!empty($search)) {
    $where_clause .= " AND (p.property_name LIKE '%$search%' OR p.owner_name LIKE '%$search%')";
}

if (!empty($status_filter)) {
    $where_clause .= " AND op.status = '$status_filter'";
}

if ($property_filter > 0) {
    $where_clause .= " AND op.property_id = $property_filter";
}

// Get owner payments
$owner_payments = $conn->query("SELECT op.*, p.property_name, p.owner_name, p.monthly_rent_to_owner
    FROM owner_payments op
    INNER JOIN properties p ON op.property_id = p.id
    WHERE $where_clause
    ORDER BY op.payment_month DESC, op.status ASC");

// Get statistics
$total_pending = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM owner_payments op
    INNER JOIN properties p ON op.property_id = p.id
    WHERE op.user_id = $user_id AND op.status = 'Pending'
    AND DATE_FORMAT(op.payment_month, '%Y-%m') = '$month'")->fetch_assoc()['total'];

$total_paid = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM owner_payments op
    INNER JOIN properties p ON op.property_id = p.id
    WHERE op.user_id = $user_id AND op.status = 'Paid'
    AND DATE_FORMAT(op.payment_month, '%Y-%m') = '$month'")->fetch_assoc()['total'];

// Get properties with owners for filter
$properties_with_owners = $conn->query("SELECT id, property_name, owner_name, monthly_rent_to_owner
    FROM properties 
    WHERE user_id = $user_id AND owner_name IS NOT NULL AND owner_name != '' AND monthly_rent_to_owner > 0
    ORDER BY property_name");

$page_title = 'Owner Payments';
include '../includes/header.php';
?>

<div class="page-actions">
    <h1>Owner Rent Payments</h1>
    <div>
        <a href="generate.php" class="btn">🔄 Generate Recurring</a>
        <a href="add.php" class="btn btn-primary" style="margin-left: 12px;">+ Record Payment</a>
    </div>
</div>

<?php if (isset($_GET['paid'])): ?>
    <div class="alert alert-success">Payment marked as paid!</div>
<?php endif; ?>

<?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-success">Payment deleted successfully!</div>
<?php endif; ?>

<div class="stats-grid" style="margin-bottom: 30px;">
    <div class="stat-card stat-expense">
        <div class="stat-icon">⏳</div>
        <div class="stat-content">
            <h3><?php echo formatCurrency($total_pending); ?></h3>
            <p>Pending Payments</p>
        </div>
    </div>
    <div class="stat-card stat-income">
        <div class="stat-icon">✅</div>
        <div class="stat-content">
            <h3><?php echo formatCurrency($total_paid); ?></h3>
            <p>Paid This Month</p>
        </div>
    </div>
</div>

<div class="content-card">
    <div class="card-header">
        <h2>Owner Payments - <?php echo date('F Y', strtotime($month . '-01')); ?></h2>
    </div>
    <div class="card-body">
        <?php if ($owner_payments->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Property</th>
                            <th>Owner</th>
                            <th>Payment Month</th>
                            <th>Amount</th>
                            <th>Paid Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($payment = $owner_payments->fetch_assoc()): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($payment['property_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($payment['owner_name'] ?? 'N/A'); ?></td>
                                <td><?php echo date('F Y', strtotime($payment['payment_month'])); ?></td>
                                <td><strong><?php echo formatCurrency($payment['amount']); ?></strong></td>
                                <td><?php echo $payment['paid_date'] ? formatDate($payment['paid_date']) : '-'; ?></td>
                                <td>
                                    <?php if ($payment['status'] == 'Paid'): ?>
                                        <span class="badge badge-success">Paid</span>
                                    <?php else: ?>
                                        <span class="badge badge-warning">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($payment['status'] == 'Pending'): ?>
                                        <a href="index.php?mark_paid=<?php echo $payment['id']; ?>" 
                                           class="btn btn-success" style="padding: 6px 12px; font-size: 12px;">Mark Paid</a>
                                    <?php endif; ?>
                                    <a href="edit.php?id=<?php echo $payment['id']; ?>" class="btn-link">Edit</a>
                                    <a href="index.php?delete=<?php echo $payment['id']; ?>" 
                                       class="btn-link text-danger" 
                                       onclick="return confirm('Are you sure you want to delete this payment?');">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted">No owner payments found for this month.</p>
            <?php if ($properties_with_owners->num_rows > 0): ?>
                <p style="margin-top: 20px;">
                    <a href="add.php" class="btn btn-primary">Record First Payment</a>
                </p>
            <?php else: ?>
                <p style="margin-top: 20px; color: #64748b;">
                    No properties with owners found. Add owner information in property settings to track owner rent payments.
                </p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php 
closeDBConnection($conn);
include '../includes/footer.php'; 
?>
