<?php
require_once '../config/config.php';
requireLogin();

$conn = getDBConnection();
$user_id = getCurrentUserId();

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: index.php');
    exit();
}

$tenant_id = intval($_GET['id']);

// Get tenant details
$tenant = $conn->query("SELECT t.*, p.property_name, p.address
    FROM tenants t
    INNER JOIN properties p ON t.property_id = p.id
    WHERE t.id = $tenant_id AND p.user_id = $user_id")->fetch_assoc();

if (!$tenant) {
    header('Location: index.php');
    exit();
}

// Get rent payments
$rent_payments = $conn->query("SELECT * FROM rent_payments WHERE tenant_id = $tenant_id ORDER BY due_date DESC LIMIT 10");

// Get tenant cheques if table exists
$check_cheque_table = $conn->query("SHOW TABLES LIKE 'tenant_cheques'");
$has_cheque_table = $check_cheque_table->num_rows > 0;

$tenant_cheques = null;
if ($has_cheque_table) {
    $tenant_cheques = $conn->query("SELECT tc.* FROM tenant_cheques tc
        WHERE tc.tenant_id = $tenant_id 
        ORDER BY tc.deposit_date ASC, tc.cheque_date ASC");
}

closeDBConnection($conn);

$page_title = 'View Tenant';
include '../includes/header.php';
?>

<div class="page-actions">
    <h1><?php echo htmlspecialchars($tenant['first_name'] . ' ' . $tenant['last_name']); ?></h1>
    <div>
        <a href="edit.php?id=<?php echo $tenant['id']; ?>" class="btn btn-primary">Edit Tenant</a>
        <a href="index.php" class="btn-link">← Back to Tenants</a>
    </div>
</div>

<div class="dashboard-grid">
    <div class="content-card">
        <div class="card-header">
            <h2>Tenant Information</h2>
        </div>
        <div class="card-body">
            <table class="data-table">
                <tr>
                    <td><strong>Name</strong></td>
                    <td><?php echo htmlspecialchars($tenant['first_name'] . ' ' . $tenant['last_name']); ?></td>
                </tr>
                <tr>
                    <td><strong>Property</strong></td>
                    <td><?php echo htmlspecialchars($tenant['property_name']); ?></td>
                </tr>
                <tr>
                    <td><strong>Email</strong></td>
                    <td><?php echo htmlspecialchars($tenant['email'] ?? '-'); ?></td>
                </tr>
                <tr>
                    <td><strong>Phone</strong></td>
                    <td><?php echo htmlspecialchars($tenant['phone'] ?? '-'); ?></td>
                </tr>
                <tr>
                    <td><strong>Monthly Rent</strong></td>
                    <td><?php echo formatCurrency($tenant['monthly_rent']); ?></td>
                </tr>
                <tr>
                    <td><strong>Security Deposit</strong></td>
                    <td><?php echo $tenant['security_deposit'] ? formatCurrency($tenant['security_deposit']) : '-'; ?></td>
                </tr>
                <tr>
                    <td><strong>Status</strong></td>
                    <td>
                        <span class="badge badge-<?php echo $tenant['status'] == 'Active' ? 'success' : 'info'; ?>">
                            <?php echo htmlspecialchars($tenant['status']); ?>
                        </span>
                    </td>
                </tr>
                <tr>
                    <td><strong>Move In Date</strong></td>
                    <td><?php echo formatDate($tenant['move_in_date'] ?? ''); ?></td>
                </tr>
                <tr>
                    <td><strong>Lease Start</strong></td>
                    <td><?php echo formatDate($tenant['lease_start'] ?? ''); ?></td>
                </tr>
                <tr>
                    <td><strong>Lease End</strong></td>
                    <td><?php echo formatDate($tenant['lease_end'] ?? ''); ?></td>
                </tr>
                <?php if ($tenant['notes']): ?>
                <tr>
                    <td><strong>Notes</strong></td>
                    <td><?php echo nl2br(htmlspecialchars($tenant['notes'])); ?></td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>

    <div class="content-card">
        <div class="card-header">
            <h2>Recent Rent Payments</h2>
            <a href="../rent/add.php?tenant_id=<?php echo $tenant['id']; ?>" class="btn-link">+ Record Payment</a>
        </div>
        <div class="card-body">
            <?php if ($rent_payments->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Due Date</th>
                                <th>Paid Date</th>
                                <th>Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($payment = $rent_payments->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo formatDate($payment['due_date']); ?></td>
                                    <td><?php echo $payment['paid_date'] ? formatDate($payment['paid_date']) : '-'; ?></td>
                                    <td><?php echo formatCurrency($payment['amount']); ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo $payment['status'] == 'Paid' ? 'success' : 'warning'; ?>">
                                            <?php echo htmlspecialchars($payment['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted">No rent payments recorded.</p>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($has_cheque_table && $tenant_cheques): ?>
    <div class="content-card mt-20">
        <div class="card-header">
            <h2>💳 Tenant Cheques</h2>
            <a href="../cheques/add_tenant_cheque.php?tenant_id=<?php echo $tenant['id']; ?>" class="btn-link">+ Add Cheque</a>
        </div>
        <div class="card-body">
            <?php if ($tenant_cheques->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Cheque #</th>
                                <th>Amount</th>
                                <th>Cheque Date</th>
                                <th>Deposit Date</th>
                                <th>Bank</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($cheque = $tenant_cheques->fetch_assoc()): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($cheque['cheque_number']); ?></strong></td>
                                    <td class="text-success"><strong><?php echo formatCurrency($cheque['cheque_amount']); ?></strong></td>
                                    <td><?php echo formatDate($cheque['cheque_date']); ?></td>
                                    <td>
                                        <?php if ($cheque['deposit_date']): ?>
                                            <?php 
                                            $deposit_date = new DateTime($cheque['deposit_date']);
                                            $today_obj = new DateTime();
                                            $is_overdue = $deposit_date < $today_obj && $cheque['status'] == 'Pending';
                                            $is_upcoming = $deposit_date >= $today_obj && $deposit_date <= (new DateTime('+7 days'));
                                            ?>
                                            <span class="<?php echo $is_overdue ? 'text-danger' : ($is_upcoming ? 'text-warning' : ''); ?>">
                                                <?php echo formatDate($cheque['deposit_date']); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">Not set</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($cheque['bank_name'] ?? '-'); ?></td>
                                    <td>
                                        <span class="badge badge-<?php 
                                            echo $cheque['status'] == 'Cleared' ? 'success' : 
                                                ($cheque['status'] == 'Deposited' ? 'info' : 
                                                ($cheque['status'] == 'Bounced' ? 'danger' : 'warning')); 
                                        ?>">
                                            <?php echo htmlspecialchars($cheque['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="../cheques/edit_tenant_cheque.php?id=<?php echo $cheque['id']; ?>" class="btn-link">Edit</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted">No cheques recorded for this tenant.</p>
                <a href="../cheques/add_tenant_cheque.php?tenant_id=<?php echo $tenant['id']; ?>" class="btn btn-primary">Add First Cheque</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
