<?php
require_once '../config/config.php';
requireLogin();

$conn = getDBConnection();
$user_id = getCurrentUserId();

// Handle delete
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $transaction_id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM transactions WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $transaction_id, $user_id);
    $stmt->execute();
    $stmt->close();
    header('Location: index.php?deleted=1');
    exit();
}

// Get search and filter parameters
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$type_filter = isset($_GET['type']) ? $conn->real_escape_string($_GET['type']) : '';
$month_filter = isset($_GET['month']) ? $conn->real_escape_string($_GET['month']) : date('Y-m');
$category_filter = isset($_GET['category']) ? $conn->real_escape_string($_GET['category']) : '';

// Build query
$where_clause = "t.user_id = $user_id";

if (!empty($search)) {
    $where_clause .= " AND (t.description LIKE '%$search%' OR t.category LIKE '%$search%' OR p.property_name LIKE '%$search%' OR CONCAT(tn.first_name, ' ', tn.last_name) LIKE '%$search%')";
}

if ($type_filter) {
    $where_clause .= " AND t.type = '$type_filter'";
}

if ($month_filter) {
    $where_clause .= " AND DATE_FORMAT(t.transaction_date, '%Y-%m') = '$month_filter'";
}

if (!empty($category_filter)) {
    $where_clause .= " AND t.category = '$category_filter'";
}

$transactions = $conn->query("SELECT t.*, p.property_name, tn.first_name, tn.last_name 
    FROM transactions t
    LEFT JOIN properties p ON t.property_id = p.id
    LEFT JOIN tenants tn ON t.tenant_id = tn.id
    WHERE $where_clause
    ORDER BY t.transaction_date DESC, t.created_at DESC");

// Get totals
$income_total = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE user_id = $user_id AND type = 'Income' AND DATE_FORMAT(transaction_date, '%Y-%m') = '$month_filter'")->fetch_assoc()['total'];
$expense_total = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE user_id = $user_id AND type = 'Expense' AND DATE_FORMAT(transaction_date, '%Y-%m') = '$month_filter'")->fetch_assoc()['total'];

// Get distinct categories for filter (keep connection open)
$categories_for_dropdown = $conn->query("SELECT DISTINCT category FROM transactions WHERE user_id = $user_id AND category IS NOT NULL AND category != '' ORDER BY category");

closeDBConnection($conn);

$page_title = 'Income & Expenses';
include '../includes/header.php';
?>

<div class="page-actions">
    <h1>Income & Expenses</h1>
    <a href="add.php" class="btn btn-primary">+ Add Transaction</a>
</div>

<?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-success">Transaction deleted successfully!</div>
<?php endif; ?>

<?php if (isset($_GET['added'])): ?>
    <div class="alert alert-success">Transaction added successfully!</div>
<?php endif; ?>

<div class="stats-grid" style="margin-bottom: 30px;">
    <div class="stat-card stat-income">
        <div class="stat-icon">💰</div>
        <div class="stat-content">
            <h3><?php echo formatCurrency($income_total); ?></h3>
            <p>Total Income</p>
        </div>
    </div>
    <div class="stat-card stat-expense">
        <div class="stat-icon">💸</div>
        <div class="stat-content">
            <h3><?php echo formatCurrency($expense_total); ?></h3>
            <p>Total Expenses</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">📊</div>
        <div class="stat-content">
            <h3><?php echo formatCurrency($income_total - $expense_total); ?></h3>
            <p>Net Profit</p>
        </div>
    </div>
</div>

<!-- Search and Filter -->
<div class="content-card" style="margin-bottom: 20px;">
    <div class="card-body">
        <form method="GET" action="" style="display: flex; gap: 12px; flex-wrap: wrap; align-items: end;">
            <div style="flex: 1; min-width: 200px;">
                <label for="search" style="font-size: 12px; margin-bottom: 4px; display: block;">Search</label>
                <input type="text" id="search" name="search" placeholder="Search by description, category, property, tenant..." value="<?php echo htmlspecialchars($search); ?>" style="width: 100%;">
            </div>
            
            <div style="min-width: 130px;">
                <label for="type_filter" style="font-size: 12px; margin-bottom: 4px; display: block;">Type</label>
                <select id="type_filter" name="type" style="width: 100%;">
                    <option value="">All Types</option>
                    <option value="Income" <?php echo $type_filter == 'Income' ? 'selected' : ''; ?>>Income</option>
                    <option value="Expense" <?php echo $type_filter == 'Expense' ? 'selected' : ''; ?>>Expense</option>
                </select>
            </div>
            
            <div style="min-width: 150px;">
                <label for="category_filter" style="font-size: 12px; margin-bottom: 4px; display: block;">Category</label>
                <select id="category_filter" name="category" style="width: 100%;">
                    <option value="">All Categories</option>
                    <?php while ($cat = $categories_for_dropdown->fetch_assoc()): ?>
                        <option value="<?php echo htmlspecialchars($cat['category']); ?>" <?php echo $category_filter == $cat['category'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($cat['category']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div style="min-width: 150px;">
                <label for="month_filter" style="font-size: 12px; margin-bottom: 4px; display: block;">Month</label>
                <input type="month" id="month_filter" name="month" value="<?php echo htmlspecialchars($month_filter); ?>" style="width: 100%;">
            </div>
            
            <div>
                <button type="submit" class="btn btn-primary">🔍 Search</button>
                <?php if (!empty($search) || !empty($type_filter) || !empty($category_filter) || !empty($month_filter)): ?>
                    <a href="index.php" class="btn" style="margin-left: 8px;">Clear</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="content-card">
    <div class="card-header">
        <h2>Transactions</h2>
    </div>
    <div class="card-body">
        <?php if ($transactions->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Type</th>
                            <th>Category</th>
                            <th>Property</th>
                            <th>Tenant</th>
                            <th>Amount</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($transaction = $transactions->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo formatDate($transaction['transaction_date']); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $transaction['type'] == 'Income' ? 'success' : 'danger'; ?>">
                                        <?php echo $transaction['type']; ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($transaction['category']); ?></td>
                                <td><?php echo htmlspecialchars($transaction['property_name'] ?? '-'); ?></td>
                                <td><?php echo $transaction['first_name'] ? htmlspecialchars($transaction['first_name'] . ' ' . $transaction['last_name']) : '-'; ?></td>
                                <td class="<?php echo $transaction['type'] == 'Income' ? 'text-success' : 'text-danger'; ?>">
                                    <?php echo $transaction['type'] == 'Income' ? '+' : '-'; ?><?php echo formatCurrency($transaction['amount']); ?>
                                </td>
                                <td><?php echo htmlspecialchars($transaction['description'] ?? '-'); ?></td>
                                <td>
                                    <a href="edit.php?id=<?php echo $transaction['id']; ?>" class="btn-link">Edit</a>
                                    <a href="?delete=<?php echo $transaction['id']; ?>" 
                                       onclick="return confirmDelete('Are you sure you want to delete this transaction?')" 
                                       class="btn-link text-danger">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center" style="padding: 60px 20px;">
                <p class="text-muted" style="font-size: 18px; margin-bottom: 20px;">No transactions found</p>
                <a href="add.php" class="btn btn-primary">Add Your First Transaction</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
